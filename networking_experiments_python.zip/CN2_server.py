import socket
import pickle

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("0.0.0.0", 9002))
server.listen(5)

print("Server waiting for connection...")
conn, addr = server.accept()
print("Connected by client:", addr)

data = pickle.loads(conn.recv(4096))
n, matrix = data

print("Received matrix of order", n, "from client:")
for row in matrix:
    print(*row)

upper = True
lower = True
diagonal = True

for i in range(n):
    for j in range(n):
        if i > j and matrix[i][j] != 0:
            upper = False
        if i < j and matrix[i][j] != 0:
            lower = False
        if i != j and matrix[i][j] != 0:
            diagonal = False

if diagonal:
    result = "Diagonal Matrix"
elif upper:
    result = "Upper Triangular Matrix"
elif lower:
    result = "Lower Triangular Matrix"
else:
    result = "Normal Matrix"

print("Identified matrix type:", result)
print("Sending result to client...")
conn.send(result.encode())

conn.close()
server.close()
