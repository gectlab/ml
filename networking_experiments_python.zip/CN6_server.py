import os
import socket
import threading


def handle_client(client_socket, address):
    pid = os.getpid()
    try:
        filename = client_socket.recv(1024).decode("utf-8").strip()
        print(f"[Server PID {pid}] Received request for '{filename}' from {address}")
        if os.path.exists(filename) and os.path.isfile(filename):
            with open(filename, "r", encoding="utf-8") as f:
                file_content = f.read()
            response = (
                f"SERVER_PID: {pid}\nSTATUS: SUCCESS\n"
                f"----------------------------------------\n{file_content}"
            )
        else:
            response = (
                f"SERVER_PID: {pid}\nSTATUS: ERROR\n"
                f"----------------------------------------\n"
                f"Error: File '{filename}' not found on the server."
            )
        client_socket.sendall(response.encode("utf-8"))
    except Exception as e:
        print(f"[Server PID {pid}] Error handling client {address}: {e}")
    finally:
        client_socket.close()


def run_server(host="127.0.0.1", port=8080):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((host, port))
    server.listen(5)
    print(f"Concurrent File Server running on {host}:{port} (PID: {os.getpid()})")
    print("Waiting for client connections...\n")
    try:
        while True:
            client_socket, address = server.accept()
            client_thread = threading.Thread(
                target=handle_client, args=(client_socket, address)
            )
            client_thread.start()
    except KeyboardInterrupt:
        print("\nShutting down server...")
    finally:
        server.close()


if __name__ == "__main__":
    run_server()
