import socket

HOST = '127.0.0.1'
PORT = 2525


def run_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print(f"[Client] Connecting to server at {HOST}:{PORT}...")

    try:
        client_socket.connect((HOST, PORT))
    except ConnectionRefusedError:
        print("[Client Error] Connection refused. Make sure server.py is running first.")
        return

    greeting = client_socket.recv(1024).decode('utf-8').strip()
    print(f"[Server Response] {greeting}\n")
    print("--- Interactive SMTP Client ---")
    print("Type commands manually (e.g., HELO localhost, MAIL FROM:<alice@example.com>, etc.)")
    print("Type 'DATA' to enter the email body, and finish it with a single '.' on a new line.")
    print("--------------------------------\n")

    try:
        while True:
            command = input("SMTP> ")

            if not command.strip():
                continue

            if command.strip().upper() == "DATA":
                client_socket.sendall((command + "\r\n").encode('utf-8'))
                response = client_socket.recv(1024).decode('utf-8').strip()
                print(f"[Server Response] {response}")
                print("Enter email body lines. Type a single '.' on a new line when done:")
                while True:
                    body_line = input()
                    client_socket.sendall((body_line + "\r\n").encode('utf-8'))
                    if body_line == ".":
                        break

                response = client_socket.recv(1024).decode('utf-8').strip()
                print(f"[Server Response] {response}\n")
                continue

            client_socket.sendall((command + "\r\n").encode('utf-8'))
            response = client_socket.recv(1024).decode('utf-8').strip()
            print(f"[Server Response] {response}\n")

            if command.strip().upper() == "QUIT":
                break

    except Exception as e:
        print(f"[Client Error] {e}")
    finally:
        client_socket.close()
        print("[Client] Disconnected.")


if __name__ == "__main__":
    run_client()
