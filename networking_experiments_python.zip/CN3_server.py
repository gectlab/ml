import socket
import re

# Dictionary of abbreviations and their expansions
ABBREVIATIONS = {
    "tbh": "to be honest",
    "ig": "I guess",
    "tbf": "to be fair",
    "atm": "at the moment",
    "irl": "in real life",
    "lol": "laughing out loud",
    "asap": "as soon as possible",
    "omg": "oh my God",
    "ttyl": "talk to you later",
    "idk": "I don't know",
    "nvm": "never mind"
}


def replace_abbreviations(text):
    """Replace abbreviations with their expanded forms."""

    def repl(match):
        word = match.group(0)
        return ABBREVIATIONS.get(word.lower(), word)

    pattern = r'\b(' + '|'.join(re.escape(k) for k in ABBREVIATIONS.keys()) + r')\b'
    return re.sub(pattern, repl, text, flags=re.IGNORECASE)


HOST = "0.0.0.0"  # INADDR_ANY
PORT = 9002

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind((HOST, PORT))

print(f"UDP Server is running on port {PORT}...")

while True:
    message, client_address = server_socket.recvfrom(1024)

    text = message.decode()

    print(f"Received from {client_address}: {text}")

    translated = replace_abbreviations(text)

    server_socket.sendto(translated.encode(), client_address)

    print(f"Sent: {translated}")

server_socket.close()
