import socket

SERVER_IP = "127.0.0.1"
SERVER_PORT = 5000

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

try:
    # Send time request to server
    message = "time"
    client_socket.sendto(
        message.encode(),
        (SERVER_IP, SERVER_PORT)
    )

    # Receive server's response
    data, server_address = client_socket.recvfrom(1024)

    print("Time received from server:")
    print(data.decode())

finally:
    client_socket.close()
