import socket
import threading
from datetime import datetime


HOST = "0.0.0.0"
PORT = 5000


def handle_client(data, client_address, server_socket):
    """Handle a client's time request."""
    request = data.decode().strip()

    if request.lower() == "time":
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        response = f"Server Time: {current_time}"
    else:
        response = "Invalid request. Send 'time'."

    server_socket.sendto(response.encode(), client_address)
    print(f"Request from {client_address}: {request}")
    print(f"Response sent: {response}")


def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((HOST, PORT))

    print(f"UDP Time Server running on port {PORT}...")
    print("Waiting for client requests...")

    while True:
        data, client_address = server_socket.recvfrom(1024)

        # Handle each client concurrently
        thread = threading.Thread(
            target=handle_client,
            args=(data, client_address, server_socket)
        )
        thread.start()


if __name__ == "__main__":
    start_server()
