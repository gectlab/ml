import socket


def run_client(host="127.0.0.1", port=8080):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        client.connect((host, port))
    except ConnectionRefusedError:
        print("Could not connect to the server. Make sure it is running.")
        return

    filename = input("Enter the name of the file you want to request: ")
    client.sendall(filename.encode("utf-8"))

    # Receive the response data in chunks
    response = b""
    while True:
        data = client.recv(4096)
        if not data:
            break
        response += data

    print("\n--- Response Received ---")
    print(response.decode("utf-8"))
    client.close()


if __name__ == "__main__":
    run_client()
