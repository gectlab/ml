import socket
import threading

SERVER_IP = "127.0.0.1"
PORT = 9002

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((SERVER_IP, PORT))

name = input("Enter your name: ")


def receive_messages():
    while True:
        try:
            message = client.recv(1024).decode()
            print(message)
        except:
            print("Disconnected from server.")
            client.close()
            break


thread = threading.Thread(target=receive_messages)
thread.daemon = True
thread.start()

while True:
    message = input()

    if message.lower() == "exit":
        break

    client.send(f"{name}: {message}".encode())

client.close()
