import socket
import pickle
import random

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 9002))

n = int(input("Enter order of matrix: "))
matrix = [[random.randint(1, 50) for j in range(n)] for i in range(n)]

matrix_type = random.choice(["upper", "lower", "diagonal", "normal"])

if matrix_type == "upper":
    for i in range(n):
        for j in range(n):
            if i > j:
                matrix[i][j] = 0
elif matrix_type == "lower":
    for i in range(n):
        for j in range(n):
            if i < j:
                matrix[i][j] = 0
elif matrix_type == "diagonal":
    for i in range(n):
        for j in range(n):
            if i != j:
                matrix[i][j] = 0

print("Matrix:")
for row in matrix:
    print(*row)

data = (n, matrix)
client.send(pickle.dumps(data))

result = client.recv(1024).decode()
print("Matrix Type:", result)

client.close()
