import socket

SERVER_IP = "127.0.0.1"
PORT = 9002

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

message = input("Enter a sentence: ")

client_socket.sendto(message.encode(), (SERVER_IP, PORT))

response, _ = client_socket.recvfrom(1024)

print("\nFormal English:")
print(response.decode())

client_socket.close()
