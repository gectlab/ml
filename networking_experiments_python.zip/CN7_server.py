import socket

HOST = '127.0.0.1'
PORT = 2525


def run_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(1)

    print(f"[Server] Listening for connections on {HOST}:{PORT}...")
    conn, addr = server_socket.accept()
    print(f"[Server] Connected by client: {addr}")

    # Send initial SMTP greeting
    conn.sendall(b"220 Simple SMTP Server Ready\r\n")

    collecting_data = False
    sender_addr = ""
    receiver_addr = ""
    email_data = []

    try:
        while True:
            data = conn.recv(1024)
            if not data:
                break

            message = data.decode('utf-8').strip()

            # If currently collecting the message body
            if collecting_data:
                if message == ".":
                    collecting_data = False
                    print("\n--- [Server] Email Processed Successfully ---")
                    print(f"sender: {sender_addr}")
                    print(f"receiver: {receiver_addr}")
                    print("<body>")
                    print("\n".join(email_data))
                    print("---------------------------------------------\n")
                    conn.sendall(b"250 OK: Message accepted for delivery\r\n")

                    # Reset variables for potential next email in same session
                    email_data = []
                    sender_addr = ""
                    receiver_addr = ""
                else:
                    email_data.append(message)
                continue

            print(f"[Server Received] {message}")
            upper_msg = message.upper()

            if upper_msg.startswith("HELO") or upper_msg.startswith("EHLO"):
                conn.sendall(b"250 Hello, pleased to meet you\r\n")
            elif upper_msg.startswith("MAIL FROM:"):
                # Extract address within brackets or raw text
                sender_addr = message[10:].strip()
                conn.sendall(b"250 Sender OK\r\n")
            elif upper_msg.startswith("RCPT TO:"):
                # Extract address within brackets or raw text
                receiver_addr = message[8:].strip()
                conn.sendall(b"250 Recipient OK\r\n")
            elif upper_msg == "DATA":
                collecting_data = True
                conn.sendall(b"354 End data with <CRLF>.<CRLF>\r\n")
            elif upper_msg == "QUIT":
                conn.sendall(b"221 Bye\r\n")
                break
            else:
                conn.sendall(b"500 Command not recognized\r\n")
    except Exception as e:
        print(f"[Server Error] {e}")
    finally:
        conn.close()
        server_socket.close()
        print("[Server] Connection closed.")


if __name__ == "__main__":
    run_server()
