import socket
import threading

HOST = "0.0.0.0"
PORT = 9002

clients = []


def broadcast(message, sender):
    for client in clients:
        if client != sender:
            client.send(message)


def handle_client(client, address):
    print(f"{address} connected.")
    clients.append(client)

    while True:
        try:
            message = client.recv(1024)

            if not message:
                break

            print(f"{address}: {message.decode()}")

            broadcast(message, client)

        except:
            break

    print(f"{address} disconnected.")
    clients.remove(client)
    client.close()


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

print(f"Server listening on port {PORT}...")

while True:
    client, address = server.accept()

    thread = threading.Thread(target=handle_client, args=(client, address))
    thread.start()
